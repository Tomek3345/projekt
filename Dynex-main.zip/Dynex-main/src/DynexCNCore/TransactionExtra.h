// Copyright (c) 2021-2023, Dynex Developers
// 
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without modification, are
// permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice, this list of
//    conditions and the following disclaimer.
// 
// 2. Redistributions in binary form must reproduce the above copyright notice, this list
//    of conditions and the following disclaimer in the documentation and/or other
//    materials provided with the distribution.
// 
// 3. Neither the name of the copyright holder nor the names of its contributors may be
//    used to endorse or promote products derived from this software without specific
//    prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
// THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
// STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
// THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// Parts of this project are originally copyright by:
// Copyright (c) 2012-2016, The CN developers, The Bytecoin developers
// Copyright (c) 2014-2018, The Monero project
// Copyright (c) 2014-2018, The Forknote developers
// Copyright (c) 2018, The TurtleCoin developers
// Copyright (c) 2016-2018, The Karbowanec developers
// Copyright (c) 2017-2022, The CROAT.community developers


#pragma once

#include <vector>
#include <algorithm> 
#include <boost/variant.hpp>

#include <DynexCN.h>

#define TX_EXTRA_PADDING_MAX_COUNT          255
#define TX_EXTRA_NONCE_MAX_COUNT            255

#define TX_EXTRA_TAG_PADDING                0x00
#define TX_EXTRA_TAG_PUBKEY                 0x01
#define TX_EXTRA_NONCE                      0x02
#define TX_EXTRA_MERGE_MINING_TAG           0x03

#define TX_EXTRA_NONCE_PAYMENT_ID           0x00

#define TX_EXTRA_FROM_ADDRESS               0x04 
#define TX_EXTRA_TO_ADDRESS                 0x05 
#define TX_EXTRA_AMOUNT                     0x06 
#define TX_EXTRA_TXKEY                      0x07

namespace DynexCN {

struct TransactionExtraPadding {
  size_t size;
};

struct TransactionExtraPublicKey {
  Crypto::PublicKey publicKey;
};

struct TransactionExtraNonce {
  std::vector<uint8_t> nonce;
};

struct TransactionExtraMergeTag {
  size_t depth;
  Crypto::Hash merkleRoot;
};

struct TransactionExtraFromAddress {
  AccountPublicAddress address;
};

struct TransactionExtraToAddress {
  AccountPublicAddress address;
};

struct TransactionExtraAmount {
  std::vector<uint8_t> amount;
};

struct TransactionExtraTxkey {
  Crypto::SecretKey tx_key;
};


// tx_extra_field format, except tx_extra_padding and tx_extra_pub_key:
//   varint tag;
//   varint size;
//   varint data[];
typedef boost::variant<TransactionExtraPadding, TransactionExtraPublicKey, TransactionExtraNonce, TransactionExtraMergeTag, TransactionExtraFromAddress, TransactionExtraToAddress, TransactionExtraAmount, TransactionExtraTxkey> TransactionExtraField;

template<typename T>
bool findTransactionExtraFieldByType(const std::vector<TransactionExtraField>& tx_extra_fields, T& field) {
  auto it = std::find_if(tx_extra_fields.begin(), tx_extra_fields.end(),
    [](const TransactionExtraField& f) { return typeid(T) == f.type(); });

  if (tx_extra_fields.end() == it)
    return false;

  field = boost::get<T>(*it);
  return true;
}

bool parseTransactionExtra(const uint8_t* data, size_t size, std::vector<TransactionExtraField>& tx_extra_fields);
bool parseTransactionExtra(const std::string& tx_extra, std::vector<TransactionExtraField>& tx_extra_fields);
bool parseTransactionExtra(const std::vector<uint8_t>& tx_extra, std::vector<TransactionExtraField>& tx_extra_fields);
bool writeTransactionExtra(std::vector<uint8_t>& tx_extra, const std::vector<TransactionExtraField>& tx_extra_fields);
Crypto::PublicKey getTransactionPublicKeyFromExtra(const std::vector<uint8_t>& tx_extra);
bool addTransactionPublicKeyToExtra(std::vector<uint8_t>& tx_extra, const Crypto::PublicKey& tx_pub_key);
bool addExtraNonceToTransactionExtra(std::vector<uint8_t>& tx_extra, const BinaryArray& extra_nonce);
void setPaymentIdToTransactionExtraNonce(BinaryArray& extra_nonce, const Crypto::Hash& payment_id);
bool getPaymentIdFromTransactionExtraNonce(const BinaryArray& extra_nonce, Crypto::Hash& payment_id);
bool appendMergeMiningTagToExtra(std::vector<uint8_t>& tx_extra, const TransactionExtraMergeTag& mm_tag);
bool getMergeMiningTagFromExtra(const std::vector<uint8_t>& tx_extra, TransactionExtraMergeTag& mm_tag);
bool createTxExtraWithPaymentId(const std::string& paymentIdString, std::vector<uint8_t>& extra);
bool getPaymentIdFromTxExtra(const std::vector<uint8_t>& extra, Crypto::Hash& paymentId);
bool parsePaymentId(const std::string& paymentIdString, Crypto::Hash& paymentId);
// non-privacy functions:
bool addFromAddressToExtra(std::vector<uint8_t>& tx_extra, const TransactionExtraFromAddress& address);
bool addFromAddressToExtraString(const AccountPublicAddress& acc, std::string& extraString);
bool addToAddressToExtra(std::vector<uint8_t>& tx_extra, const TransactionExtraToAddress& address); 
bool addAmountToExtra(std::vector<uint8_t>& tx_extra, const BinaryArray& amount); 
bool addTxkeyToExtra(std::vector<uint8_t>& tx_extra, const Crypto::SecretKey& tx_key);
bool addTxkeyToExtraString(const Crypto::SecretKey& tx_key, std::string& extraString);
bool addToAddressAmountToExtraString(const AccountPublicAddress& acc, const int64_t amount, std::string& extraString);
std::string getAccountAddressAsStr(const AccountPublicAddress& address);
AccountPublicAddress getAccountAddressAsKeys(const std::string& address_str);
int64_t getAmountInt64(const std::vector<uint8_t>& amount);
int64_t getStringAmountInt64(const std::string& amount);
BinaryArray getBinaryAmount(int64_t amount);
}
